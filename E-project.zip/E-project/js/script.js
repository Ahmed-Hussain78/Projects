let camera = document.querySelector("#cameradata")
let rowdata = document.querySelector("#cameraData");
let y="";
for(let firstkey in camera){
    for(let i=0;i<camera[firstkey].length;i++){
        y+=`<div class="col-md-4 col-lg-3 col-sm-6 mt-5">
        <div class="card ">
        <img src="${camera[firstkey][i].image}" class="card-img-top" alt="...">
        <div class="card-body">
          <h6 class="card-nam card-title">${camera[firstkey][i].name}</h6>
          <div class="card-pric d-flex">
          // <p class="card-text">${camera[firstkey][i].description}</p></br>
          <h5 class="pric card-title">${camera[firstkey][i].price}</h5>
        </div>
        <div class="d-flex">
          <a href="#" class="atag" data-bs-toggle="modal" data-bs-target="#staticBackdrop${camera[firstkey][i].id}" >LEARN MORE</a>

        </div>
        </div>
      </div>
      </div>`;
    }
}


rowdata.innerHTML = y;
// End of Mobile Cards

// Modal

let md = "";
for(let modalKey in camera){
  for(let i = 0; i<camera[modalKey].length; i++){
md+=`<div class="modal " id="staticBackdrop${camera[modalKey][i].id}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
<div class="modal-dialog modal-lg">
<div class="modal-content">
  <div class="modal-header">
    <h5 class="modal-title" id="staticBackdropLabel" style= color:black;>${camera[modalKey][i].name}</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>
  <div class="modal-body">
   <div class="row justify-content-center ">
    <div class="col-lg-4">
      <div class="">
        <img src="${camera[modalKey][i].image}" class="card-img-top" alt="...">
      </div>
    </div>
    <div class="col-lg-6">
      <div class="">
        <h5 class="card-header" style= color:black;>${camera[modalKey][i].name}</h5>
        <div class="card-body" style= color:black;>
          <h5 class="card-title" style= color:black;>Price: ${camera[modalKey][i].price}</h5>
          <h6 class="card-text" style= color:black;>:</h6>
          <p class="mod-p card-text" style= color:black;>${camera[modalKey][i].description}</p>
          <h6 class="card-text" style= color:black;>Features:</h6>
          <p class="mod-p card-text"style= color:black;>${camera[modalKey][i].price}</p>
        </div>
      </div>
    </div>
   </div>
  </div>
  <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <button type="button" class="btn btn-primary">Save changes</button>
  </div>
</div>
</div>
</div>`
  }
}
document.querySelector("#mdlData").innerHTML=md;

// // search function
function searchBrand(){
    let searchData = document.querySelector("#searchData").value.toLowerCase();
    let y ="";
    for(let firstKey in camera){
        if(firstKey == searchData){
            for(i=0;i<camera[firstKey].length; i++){
                y+=`<div class="col-lg-3 col-md-4 col-sm-6 mt-3">
                <div class="card" >
                  <img src="${camera[firstKey][i].image}" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title">`+camera[firstKey][i].name+`</h5>
                    <h5 class="card-title">Price:`+camera[firstKey][i].price+`</h5>
                    <h5 class=" mod-p card-text">description:`+camera[firstKey][i].description+`</h5>
                    <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#">Detail</a>
                  </div>
                </div>
                </div>`
            }
        }     
    }
     rowData.innerHTML = y;
  }
