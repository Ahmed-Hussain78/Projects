function logIn(){
    let uEmail = document.querySelector("#uEmail").value;
    let uPassword = document.querySelector("#uPassword").value;
    let getLocalEmail= localStorage.getItem('uEmail');
    let getLocalPassword = localStorage.getItem('uPassword');
    // console.log(getLocalEmail)
    if(uEmail && uPassword){
        if(uEmail == getLocalEmail && uPassword == getLocalPassword){
            alert('logged in successfully');
            window.location.href = "/assets/html/index.html"
        }else{
            alert('invalid data');
        }
    }
    else{
        alert('every field is required to fill');
    }
}