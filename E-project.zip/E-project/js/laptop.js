
$(document).ready(function(){
    $.ajax({
     url:"/json/laptop.json",
     type:"get",
     success:function(data){
      let x = "";
      let md = "";
      $.each(data,function(keys,arraData){
        $.each(arraData,function(index,objects){
         x+=`<div class=" col-md-4 col-md-6 col-md-9 col-md-12 col-lg-3 col-sm-6 mt-5">
                <div class="card"  style="background-color:transparent;">
                <img src="${objects.image}" class="card-img-top" alt="...">
                <div class="card-body">
                  <h6 class="card-nam card-title">${objects.name}</h6>
                  <div class="card-pric d-flex">
                  <h5 class="price card-title">${objects.price}</h5>
                </div>
                <div>   
                  <a href="#" class="atag" data-bs-toggle="modal" data-bs-target="#staticBackdrop${objects.id}" >LEARN MORE</a>
                </div>  
                </div>
              </div>
              </div>`;
              // modal'
              md+=`<div class="modal " id="staticBackdrop${objects.id}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg">
   <div class="modal-content">
     <div class="modal-header">
       <h5 class="modal-title" id="staticBackdropLabel">${objects.name}</h5>
       <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
     </div>

     <div class="modal-body">
      <div class="row justify-content-center ">
       <div class="col-lg-4">
         <div class="">
           <img src="${objects.image}" class="card-img-top" alt="...">
         </div>
       </div>
       <div class="col-lg-6">
         <div class="cards" style=color:black;>
           <h5 class="card-header"style= color:black; >${objects.name}</h5>
           <div class="card-body" style= color:black;>
             <h5 class="card-title" style= color:black;>Price: ${objects.price}</h5>
             <h6 class="card-text" style= color:black;>Colors:</h6>
             <p class="mod-p card-text" style= color:black;>${objects.color}</p>
             <h6 class="card-text" style= color:black;>Features:</h6>
             <p class="mod-p card-text" style= color:black;>${objects.description}</p>
         </div>
       </div>
      </div>
     </div>
     <div class="modal-footer">
       <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" style= color:black;>Close</button>

     </div>
   </div>
   </div>
   </div>`;
        })
      })
      $("#laptopdata").html(x)
      $("#mdlData").html(md)
     }
    })
   })